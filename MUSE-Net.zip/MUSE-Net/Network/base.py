import numpy as np
import tensorflow as tf
from keras.layers import Input,Activation,Dropout,BatchNormalization,AveragePooling2D,GlobalAveragePooling2D, GlobalMaxPooling2D, Multiply, Dense, Permute
from keras.layers import Lambda,Reshape,Concatenate,Add
from keras.models import Model
from keras.layers.convolutional import Conv2D
from keras.layers import Layer
import keras.backend as K


# Relu-BN-Conv2D 3x3
def conv_unit0(Fin, Fout, drop, H, W):
    unit_input = Input(shape=(Fin, H, W))

    unit_conv = Activation('relu')(unit_input)
    unit_conv = BatchNormalization()(unit_conv)
    unit_conv = Dropout(drop)(unit_conv)
    unit_output = Conv2D(filters=Fout, kernel_size=(3, 3), padding="same")(unit_conv)
    unit_model = Model(inputs=unit_input, outputs=unit_output)
    print('kernel=(3,3)')
    return unit_model


# Relu-BN-Conv2D 1x1
def conv_unit1(Fin, Fout, drop, H, W):
    unit_input = Input(shape=(Fin, H, W))

    unit_conv = Activation('relu')(unit_input)
    unit_conv = BatchNormalization()(unit_conv)
    unit_conv = Dropout(drop)(unit_conv)
    unit_output = Conv2D(filters=Fout, kernel_size=(1, 1), padding="same")(unit_conv)
    unit_model = Model(inputs=unit_input, outputs=unit_output)
    print('kernel=(1,1)')
    return unit_model


# new resdual block
def Res_plus(F, Fplus, rate, drop, H, W):
    cl_input = Input(shape=(F, H, W))

    cl_conv1A = conv_unit0(F, F - Fplus, drop, H, W)(cl_input)

    if rate == 1:
        cl_conv1B = cl_input
    if rate != 1:
        cl_conv1B = AveragePooling2D(pool_size=(rate, rate), strides=(rate, rate), padding="valid")(cl_input)

    cl_conv1B = Activation('relu')(cl_conv1B)
    cl_conv1B = BatchNormalization()(cl_conv1B)

    plus_conv = Conv2D(filters=Fplus * H * W, kernel_size=(int(np.floor(H / rate)), int(np.floor(W / rate))),
                       padding="valid")

    cl_conv1B = plus_conv(cl_conv1B)

    cl_conv1B = Reshape((Fplus, H, W))(cl_conv1B)

    cl_conv1 = Concatenate(axis=1)([cl_conv1A, cl_conv1B])

    cl_conv2 = conv_unit0(F, F, drop, H, W)(cl_conv1)

    cl_out = Add()([cl_input, cl_conv2])

    cl_model = Model(inputs=cl_input, outputs=cl_out)

    return cl_model

def channel_attention(H=10, W=20, channel=128, reduction_ratio=0.5):
    # get channel
    if K.image_data_format() == "channels_first":
        input_xs = Input(shape=(channel, H, W))
        channel_axis = 1
    else:
        input_xs = Input(shape=(H, W, channel))
        channel_axis = 3
    maxpool_channel = GlobalMaxPooling2D(data_format=K.image_data_format())(input_xs)
    maxpool_channel = Reshape((1, 1, channel))(maxpool_channel)
    avgpool_channel = GlobalAveragePooling2D(data_format=K.image_data_format())(input_xs)
    avgpool_channel = Reshape((1, 1, channel))(avgpool_channel)
    if channel_axis == 1:
        K.set_image_data_format('channels_last')
    Dense_One = Dense(units=int(channel * reduction_ratio), activation='relu', kernel_initializer='he_normal', use_bias=True, bias_initializer='zeros')
    Dense_Two = Dense(units=int(channel), activation='relu', kernel_initializer='he_normal', use_bias=True, bias_initializer='zeros')
    # max path
    mlp_1_max = Dense_One(maxpool_channel)
    mlp_2_max = Dense_Two(mlp_1_max)
    mlp_2_max = Reshape(target_shape=(1, 1, int(channel)))(mlp_2_max)
    # avg path
    mlp_1_avg = Dense_One(avgpool_channel)
    mlp_2_avg = Dense_Two(mlp_1_avg)
    mlp_2_avg = Reshape(target_shape=(1, 1, int(channel)))(mlp_2_avg)
    if channel_axis == 1:
        K.set_image_data_format('channels_first')
    channel_attention_feature = Add()([mlp_2_max, mlp_2_avg])
    channel_attention_feature = Activation('sigmoid')(channel_attention_feature)
    if K.image_data_format() == "channels_first":
        channel_attention_feature = Permute((3, 1, 2))(channel_attention_feature)
    output_xs = Multiply()([channel_attention_feature, input_xs])
    channel_att = Model(inputs=input_xs, outputs=output_xs)
    return channel_att

# SAM
def spatial_attention(H=10, W=20, channel=128):
    if K.image_data_format() == "channels_first":
        input_xs = Input(shape=(channel, H, W))
        channel_axis = 1
    else:
        input_xs = Input(shape=(H, W, channel))
        channel_axis = 3
    maxpool_spatial = Lambda(lambda x: K.max(x, axis=channel_axis, keepdims=True))(input_xs)
    avgpool_spatial = Lambda(lambda x: K.mean(x, axis=channel_axis, keepdims=True))(input_xs)
    max_avg_pool_spatial = Concatenate(axis=channel_axis)([maxpool_spatial, avgpool_spatial])

    output_xs = Conv2D(filters=1, kernel_size=(3, 3), padding="same", activation='sigmoid', kernel_initializer='he_normal', use_bias=False)(max_avg_pool_spatial)
    spatial_att = Model(inputs=input_xs, outputs=output_xs)
    return spatial_att

def attention(H=10, W=20, channel=128, reduction_ratio=0.5):
    if K.image_data_format() == "channels_first":
        input_xs = Input(shape=(channel, H, W))
    else:
        input_xs = Input(shape=(H, W, channel))
    channel_refined_feature = channel_attention(H, W, channel, reduction_ratio)(input_xs)
    spatial_attention_feature = spatial_attention(H, W, channel)(channel_refined_feature)
    refined_feature = Multiply()([channel_refined_feature, spatial_attention_feature])
    output_xs = Add()([refined_feature, input_xs])
    att_model = Model(inputs=input_xs, outputs=output_xs)
    # output_xs = channel_attention(H, W, channel, reduction_ratio)(input_xs)
    # att_model = Model(inputs=input_xs, outputs=output_xs)
    return att_model